package com.example.db_practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbPracticeApplication {

    public static void main(String[] args) {
        SpringApplication.run(DbPracticeApplication.class, args);
    }

}
